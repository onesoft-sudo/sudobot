# waifu.pics

This extension allows you to get random waifu images from [waifu.pics](https://waifu.pics/).
