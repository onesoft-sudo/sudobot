# Counting

This extension can set up a channel where you can play a counting game.
