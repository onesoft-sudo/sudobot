# Extension: Anti RickRoll

Annoyed of RickRolls? This extension prevents RickRoll links from being sent in your server, and never gives you up.
